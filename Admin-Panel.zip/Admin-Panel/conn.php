<?php
    $con = mysqli_connect('localhost','root','Sorav@123');
    mysqli_select_db($con,'admin');  
?>